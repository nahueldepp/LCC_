.global main
main:
    movq $0x4545454FF, %rax
    movq $0, %rbx
    movq $64, %rcx

while_1:
    cmpq $0,%rcx
    jz fin

fin:
